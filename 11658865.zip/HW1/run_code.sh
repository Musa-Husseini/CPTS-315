rm output.txt
python HW1Code.py
